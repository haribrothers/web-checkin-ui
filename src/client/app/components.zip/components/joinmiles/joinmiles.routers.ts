import { JoinmilesComponent } from './joinmiles.component';

export const JoinMiles: Array<any> = [
  {
    path: 'joinmiles',
    component: JoinmilesComponent
  }
];
