import { FlightPaxInfoComponent } from './flightPaxInfo.component';

export const FlightPaxInfoRoutes: Array<any> = [
  {
    path: 'flightPaxInfo',
    component: FlightPaxInfoComponent
  }
];