import { TermsComponent } from './terms.component';

export const TermsRoutes: Array<any> = [
  {
    path: 'terms',
    component: TermsComponent
  }
];