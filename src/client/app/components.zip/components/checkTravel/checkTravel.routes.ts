import { CheckTravelComponent } from './checkTravel.component';

export const CheckTravelRoutes: Array<any> = [
  {
    path: 'checkTravel',
    component: CheckTravelComponent
  }
];